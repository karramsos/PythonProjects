rst_epilog = """
.. |min-perl-ver| replace:: 5.10.1

.. Module Versions

.. |min-cgi-ver| replace:: 3.51
.. |min-digest-sha-ver| replace:: any
.. |min-date-format-ver| replace:: 2.23
.. |min-datetime-ver| replace:: 0.28
.. |min-datetime-timezone-ver| replace:: 0.71
.. |min-dbi-ver| replace:: 1.54
.. |min-template-ver| replace:: 2.24
.. |min-email-send-ver| replace:: 2.04
.. |min-email-mime-ver| replace:: 1.904
.. |min-uri-ver| replace:: 1.37
.. |min-list-moreutils-ver| replace:: 0.32
.. |min-math-random-isaac-ver| replace:: 1.0.1
.. |min-gd-ver| replace:: 1.20
.. |min-chart-lines-ver| replace:: 2.4.1
.. |min-template-plugin-gd-image-ver| replace:: any
.. |min-gd-text-ver| replace:: any
.. |min-gd-graph-ver| replace:: any
.. |min-mime-parser-ver| replace:: 5.406
.. |min-lwp-useragent-ver| replace:: any
.. |min-xml-twig-ver| replace:: any
.. |min-patchreader-ver| replace:: 0.9.6
.. |min-net-ldap-ver| replace:: any
.. |min-authen-sasl-ver| replace:: any
.. |min-net-smtp-ssl-ver| replace:: 1.01
.. |min-authen-radius-ver| replace:: any
.. |min-soap-lite-ver| replace:: 0.712
.. |min-xmlrpc-lite-ver| replace:: 0.712
.. |min-json-rpc-ver| replace:: any
.. |min-json-xs-ver| replace:: 2.0
.. |min-test-taint-ver| replace:: 1.06
.. |min-html-parser-ver| replace:: 3.40
.. |min-html-scrubber-ver| replace:: any
.. |min-encode-ver| replace:: 2.21
.. |min-encode-detect-ver| replace:: any
.. |min-email-reply-ver| replace:: any
.. |min-html-formattext-withlinks-ver| replace:: 0.13
.. |min-theschwartz-ver| replace:: 1.07
.. |min-daemon-generic-ver| replace:: any
.. |min-mod_perl2-ver| replace:: 1.999022
.. |min-apache2-sizelimit-ver| replace:: 0.96
.. |min-file-mimeinfo-magic-ver| replace:: any
.. |min-io-scalar-ver| replace:: any
.. |min-cache-memcached-ver| replace:: any

.. Database Versions

.. |min-dbd-pg-ver| replace:: 2.7.0
.. |min-pg-ver| replace:: 8.03.0000
.. |min-dbd-mysql-ver| replace:: 4.001
.. |min-mysql-ver| replace:: 5.0.15
.. |min-dbd-sqlite-ver| replace:: 1.29
.. |min-sqlite-ver| replace:: 3.6.22
.. |min-dbd-oracle-ver| replace:: 1.19
.. |min-oracle-ver| replace:: 10.02.0
"""